
#include <GUIConstants.au3>
#include <AutoItConstants.au3>
#include <MsgBoxConstants.au3>
#include <GUIConstantsEx.au3>
#include <FontConstants.au3>
#include <ButtonConstants.au3>
#include <ComboConstants.au3>
#include <GuiComboBox.au3>
#include <GuiEdit.au3>
#include <Array.au3>
#include "CommInterface.au3"
#include "GraphGDIPlus.au3"


$Version = "1.1"

$hGUI 						= GUICreate ("PZEM-004T PC Serial Interface v"&$Version, 820, 680,-1,-1,Default,Default)
$CTRL_labelPort				= GUICtrlCreateLabel("Port:", 10, 16, 30,25)
$CTRL_PortsComboList		= GUICtrlCreateCombo("", 35, 11, 200, 25)
$CTRL_btnRefreshPortList 	= GUICtrlCreateButton("Refresh list", 245, 10, 60, 23)
$CTRL_btnOpenPort 			= GUICtrlCreateButton("Connect", 310, 10, 60, 23)

$CTRL_labelDevType			= GUICtrlCreateLabel("Dev.type:", 400, 16, 60,25)
$CTRL_DevtypesComboList		= GUICtrlCreateCombo("", 450, 11, 110, 25, $CBS_DROPDOWNLIST)
;$CTRL_btnPortSettings 		= GUICtrlCreateButton("Settings", 620, 10, 60, 23)

Global $pzemPollingDelay	= 2000

$CTRL_labelPollingDelay 	= GUICtrlCreateLabel("Delay:", 590, 16, 35, 25)
$CTRL_inputPollingDelay 	= GUICtrlCreateInput($pzemPollingDelay, 625, 11, 60, 22)

$CTRL_TimeunitsComboList	= GUICtrlCreateCombo("", 690, 11, 40, 25, $CBS_DROPDOWNLIST)
GUICtrlSetData($CTRL_TimeunitsComboList, "ms|sec", "ms")

$CTRL_btnChangePollingDelay = GUICtrlCreateButton("OK", 735, 10, 25, 23)
$CTRL_btnResetEnergy 		= GUICtrlCreateButton("R" & @CRLF & "E" & @CRLF & "S" & @CRLF & "E" & @CRLF & "T", 375, 126, 25, 70, $BS_MULTILINE)
$CTRL_editLOG 				= GUICtrlCreateEdit( "", 10, 530, 780, 140, $ES_AUTOVSCROLL + $WS_VSCROLL + $ES_READONLY)


GUICtrlSetTip( $CTRL_btnRefreshPortList, "Refresh the list of available ports")
GUICtrlSetTip( $CTRL_btnOpenPort, "Connect to PZEM on the selected COM port")
GUICtrlSetTip( $CTRL_DevtypesComboList, "Select the device type")
GUICtrlSetTip( $CTRL_inputPollingDelay, "Input polling interval")
GUICtrlSetTip( $CTRL_btnChangePollingDelay, "Apply polling interval")
GUICtrlSetTip( $CTRL_btnResetEnergy, "Reset internal energy counter")

GUICtrlSetData($CTRL_DevtypesComboList, "PZEM 004T V2.0|PZEM 004T V3.0", "PZEM 004T V3.0")

$CTRL_checkboxV				= GUICtrlCreateCheckbox("Enable", 293, 45, 55, 25 )
$CTRL_checkboxI				= GUICtrlCreateCheckbox("Enable", 765, 45, 60, 25 )
$CTRL_checkboxP				= GUICtrlCreateCheckbox("Enable", 293, 125, 55, 25 )
$CTRL_checkboxW				= GUICtrlCreateCheckbox("Enable", 765, 125, 60, 25 )
$CTRL_checkboxPF			= GUICtrlCreateCheckbox("Enable", 293, 205, 55, 25 )
$CTRL_checkboxF				= GUICtrlCreateCheckbox("Enable", 765, 205, 55, 25 )

$CTRL_checkboxVl				= GUICtrlCreateCheckbox("Log", 293, 70, 55, 25 )
$CTRL_checkboxIl				= GUICtrlCreateCheckbox("Log", 765, 70, 60, 25 )
$CTRL_checkboxPl				= GUICtrlCreateCheckbox("Log", 293, 150, 55, 25 )
$CTRL_checkboxWl				= GUICtrlCreateCheckbox("Log", 765, 150, 60, 25 )
$CTRL_checkboxPFl				= GUICtrlCreateCheckbox("Log", 293, 230, 55, 25 )
$CTRL_checkboxFl				= GUICtrlCreateCheckbox("Log", 765, 230, 55, 25 )

$CTRL_checkboxVg				= GUICtrlCreateCheckbox("Graph", 293, 95, 55, 25 )
$CTRL_checkboxIg				= GUICtrlCreateCheckbox("Graph", 765, 95, 60, 25 )
$CTRL_checkboxPg				= GUICtrlCreateCheckbox("Graph", 293, 175, 55, 25 )
$CTRL_checkboxWg				= GUICtrlCreateCheckbox("Graph", 765, 175, 60, 25 )
$CTRL_checkboxPFg				= GUICtrlCreateCheckbox("Graph", 293, 255, 55, 25 )
$CTRL_checkboxFg				= GUICtrlCreateCheckbox("Graph", 765, 255, 55, 25 )


; labels that contain the actual data (value that is measured)
$CTRL_labelV 				= GUICtrlCreateLabel("-----", 10, 50, 230,62,$SS_RIGHT)
$CTRL_labelI 				= GUICtrlCreateLabel("------", 402, 50, 270,62,$SS_RIGHT)
$CTRL_labelP 				= GUICtrlCreateLabel("-----", 10, 130, 230,62,$SS_RIGHT)
$CTRL_labelW 				= GUICtrlCreateLabel("------", 402, 130, 270,62,$SS_RIGHT)
$CTRL_labelPF 				= GUICtrlCreateLabel("-----", 10, 210, 230,62,$SS_RIGHT)
$CTRL_labelF 				= GUICtrlCreateLabel("------", 402, 210, 270,62,$SS_RIGHT)

; labels that contain the name of units
$CTRL_labelVx 				= GUICtrlCreateLabel("V", 242, 50, 50,62,$SS_LEFT)
$CTRL_labelIx 				= GUICtrlCreateLabel("A", 674, 50, 50,62,$SS_LEFT)
$CTRL_labelPx 				= GUICtrlCreateLabel("W", 242, 130, 50,62,$SS_LEFT)
$CTRL_labelWx 				= GUICtrlCreateLabel("Wh", 674, 130, 90,62,$SS_LEFT)
$CTRL_labelPFx 				= GUICtrlCreateLabel("φ", 242, 210, 50,62,$SS_LEFT)
$CTRL_labelFx 				= GUICtrlCreateLabel("Hz", 674, 210, 90,62,$SS_LEFT)


Local $labelBgDark				= 0xE0E0E0
Local $labelBgLite				= 0xE5E5E5

GUICtrlSetFont($CTRL_labelV, 55, $FW_SEMIBOLD,  $GUI_FONTNORMAL, "Lucida Console")
GUICtrlSetBkColor ( $CTRL_labelV,  $labelBgDark )
GUICtrlSetFont($CTRL_labelI, 55, $FW_SEMIBOLD,  $GUI_FONTNORMAL, "Lucida Console")
GUICtrlSetBkColor ( $CTRL_labelI,  $labelBgDark )
GUICtrlSetFont($CTRL_labelP, 55, $FW_SEMIBOLD,  $GUI_FONTNORMAL, "Lucida Console")
GUICtrlSetBkColor ( $CTRL_labelP,  $labelBgDark )
GUICtrlSetFont($CTRL_labelW, 55, $FW_SEMIBOLD,  $GUI_FONTNORMAL, "Lucida Console")
GUICtrlSetBkColor ( $CTRL_labelW,  $labelBgDark )
GUICtrlSetFont($CTRL_labelPF, 55, $FW_SEMIBOLD,  $GUI_FONTNORMAL, "Lucida Console")
GUICtrlSetBkColor ( $CTRL_labelPF,  $labelBgDark )
GUICtrlSetFont($CTRL_labelF, 55, $FW_SEMIBOLD,  $GUI_FONTNORMAL, "Lucida Console")
GUICtrlSetBkColor ( $CTRL_labelF,  $labelBgDark )

GUICtrlSetFont($CTRL_labelVx, 55, $FW_SEMIBOLD,  $GUI_FONTNORMAL, "Lucida Console")
GUICtrlSetBkColor ( $CTRL_labelVx,  $labelBgLite )
GUICtrlSetFont($CTRL_labelIx, 55, $FW_SEMIBOLD,  $GUI_FONTNORMAL, "Lucida Console")
GUICtrlSetBkColor ( $CTRL_labelIx,  $labelBgLite )
GUICtrlSetFont($CTRL_labelPx, 55, $FW_SEMIBOLD,  $GUI_FONTNORMAL, "Lucida Console")
GUICtrlSetBkColor ( $CTRL_labelPx,  $labelBgLite )
GUICtrlSetFont($CTRL_labelWx, 55, $FW_SEMIBOLD,  $GUI_FONTNORMAL, "Lucida Console")
GUICtrlSetBkColor ( $CTRL_labelWx,  $labelBgLite )
GUICtrlSetFont($CTRL_labelPFx, 55, $FW_SEMIBOLD,  $GUI_FONTNORMAL, "Lucida Console")
GUICtrlSetBkColor ( $CTRL_labelPFx,  $labelBgLite )
GUICtrlSetFont($CTRL_labelFx, 55, $FW_SEMIBOLD,  $GUI_FONTNORMAL, "Lucida Console")
GUICtrlSetBkColor ( $CTRL_labelFx,  $labelBgLite )

GUICtrlSetColor ( $CTRL_labelV, 0xEE0000 )
GUICtrlSetState ($CTRL_labelV,$GUI_DISABLE)
GUICtrlSetColor ( $CTRL_labelI, 0xEE0000 )
GUICtrlSetState ($CTRL_labelI,$GUI_DISABLE)
GUICtrlSetColor ( $CTRL_labelP, 0xEE0000 )
GUICtrlSetState ($CTRL_labelP,$GUI_DISABLE)
GUICtrlSetColor ( $CTRL_labelW, 0xEE0000 )
GUICtrlSetState ($CTRL_labelW,$GUI_DISABLE)
GUICtrlSetColor ( $CTRL_labelPF, 0xEE0000 )
GUICtrlSetState ($CTRL_labelPF,$GUI_DISABLE)
GUICtrlSetColor ( $CTRL_labelF, 0xEE0000 )
GUICtrlSetState ($CTRL_labelF,$GUI_DISABLE)


GUICtrlSetColor ( $CTRL_labelVx, 0x00CC00 )
GUICtrlSetColor ( $CTRL_labelIx, 0x00CC00 )
GUICtrlSetColor ( $CTRL_labelPx, 0x00CC00 )
GUICtrlSetColor ( $CTRL_labelWx, 0x00CC00 )
GUICtrlSetColor ( $CTRL_labelPFx, 0x00CC00 )
GUICtrlSetColor ( $CTRL_labelFx, 0x00CC00 )



;----- Create Graph area -----
$Graph = _GraphGDIPlus_Create($hGUI,50,290,740,210,0xFF000000,0xFF88B3DD)
Global $graphXResolution = 180

initGraphArea()


Global $commPortsList
Global $sList = ""
Global $portIsOpen = 0
Global $openedPortNum = 0
Global $hPort

Global $curDevVersion = 3

;PZEM v2.0 variables
Const $PZEM_REQ_V = 1
Const $PZEM_REQ_I = 2
Const $PZEM_REQ_P = 3
Const $PZEM_REQ_W = 4

Global $pzemReqList[5] = [0,0,0,0,0]
Global $pzemCurReqPointer = 0  ;index in array

Global $pzemPortDataReceived[128];
Global $pzemPortDataPointer = 0;


Const $pzem_readV    = "0xB0C0A80101001A" ; pzem v2
Const $pzem_readI    = "0xB1C0A80101001B" ; pzem v2
Const $pzem_readP    = "0xB2C0A80101001C" ; pzem v2
Const $pzem_readW    = "0xB3C0A80101001D" ; pzem v2
Const $pzem_setaddr  = "0xB4C0A80101001E" ; pzem v2

Const $pzem_resetEnergyReq	= "0xF842C241" ; pzem v3
Const $pzem_getMeasReq		= "0xF804000000092465" 
Const $pzem_measOKlen 		= 23
Const $pzem_measOKcode		= 0x04
Const $pzem_measERRlen		= 5
Const $pzem_measERRcode		= 0x84
Const $pzem_nrjResOKlen		= 4
Const $pzem_nrjResOKcode	= 0x42
Const $pzem_nrjResERRlen	= 5
Const $pzem_nrjResERRcode	= 0xC2

Global $pzemNextReq = $pzemReqList[$pzemCurReqPointer]

Global $portReadTimeout = 50 ;ms
Global $pzemReqTimer = TimerInit()
Global $pzemInitialized = 0

Global $doLogVoltage 		= False
Global $doPlotVoltage		= False
Global $doLogCurrent 		= False
Global $doPlotCurrent		= False
Global $doLogPower 			= False
Global $doPlotPower			= False
Global $doLogEnergy 		= False
Global $doPlotEnergy		= False
Global $doLogPowerFactor 	= False
Global $doPlotPowerFactor	= False
Global $doLogFrequency 		= False
Global $doPlotFrequency		= False

; arrays for graphs.Graph size is fixed to 180 points. X coord is sequential number of measurement
; coord Y is a value of measurement

Global $doResetEnergy		= False

Global $voltageArr[$graphXResolution][2]
Global $currentArr[$graphXResolution][2]
Global $powerArr[$graphXResolution][2]
Global $energyArr[$graphXResolution][2]
Global $powerfactorArr[$graphXResolution][2]
Global $frequencyArr[$graphXResolution][2]
Global $emptyArr[$graphXResolution][2]

Global $voltageTick = 0
Global $currentTick = 0
Global $powerTick = 0
Global $energyTick = 0
Global $powerfactorTick = 0
Global $frequencyTick = 0

; store previous values to avoid unneccessary label updates
Global $graphYmin = 0
Global $graphYmax = 0
Global $graphPrecision = 0

initGraphArray($voltageArr)
initGraphArray($currentArr)
initGraphArray($powerArr)
initGraphArray($energyArr)
initGraphArray($powerfactorArr)
initGraphArray($frequencyArr)
initGraphArray($emptyArr)

Global $logMessageLimit = 512;
Global $logArray[$logMessageLimit]
_GUICtrlEdit_SetLimitText($CTRL_editLOG, $logMessageLimit)

updateCommPortsComboList()
resetGUI(3)
GUISetState()


logString("App is launched")

Do
	$msg = GUIGetMsg()

	Select
	Case $msg = $CTRL_DevtypesComboList
		logString("Target device has been changed" )
		If $portIsOpen = 1 Then closePort()

		Local $selectedDevice = GUICtrlRead($CTRL_DevtypesComboList)
		If $selectedDevice == "PZEM 004T V2.0" Then
			$curDevVersion = 2
			resetGUI(2)
		Else
			$curDevVersion = 3
			resetGUI(3)
		EndIf
		$pzemPortDataPointer 	= 0
		$voltageTick 			= 0
		$currentTick 			= 0
		$powerTick 				= 0
		$energyTick 			= 0
		$powerfactorTick 		= 0
		$frequencyTick 			= 0
		$doLogVoltage 		= False
		$doPlotVoltage		= False
		$doLogCurrent 		= False
		$doPlotCurrent		= False
		$doLogPower 		= False
		$doPlotPower		= False
		$doLogEnergy 		= False
		$doPlotEnergy		= False
		$doLogPowerFactor 	= False
		$doPlotPowerFactor	= False
		$doLogFrequency 	= False
		$doPlotFrequency	= False
		initGraphArray($voltageArr)
		initGraphArray($currentArr)
		initGraphArray($powerArr)
		initGraphArray($energyArr)
		initGraphArray($powerfactorArr)
		initGraphArray($frequencyArr)
	Case $msg = $CTRL_btnChangePollingDelay
		Local $ms	= GUICtrlRead($CTRL_TimeunitsComboList)	
		Local $tm1 	= GUICtrlRead($CTRL_inputPollingDelay)
		
		If $ms == "ms" And checkInputField($tm1, 100, 86400000) Then
			$pzemPollingDelay = $tm1
			logString("Changing polling interval to  " & $tm1 & " " & $ms )
		ElseIf $ms == "sec" And checkInputField($tm1, 1, 86400) Then
			$pzemPollingDelay = $tm1 * 1000
			logString("Changing polling interval to  " & $tm1 & " " & $ms )
		Else
			logString("ERROR while setting new polling interval: " & $tm1 & $ms )
		EndIf
	Case $msg = $CTRL_btnRefreshPortList
		logString("Refreshing the list of available serial ports" )
		updateCommPortsComboList()
	Case $msg = $CTRL_btnOpenPort
		If $portIsOpen = 0 Then
			If openPort() = 1 Then
				PZEM_init()
			Else
				logString("Error while trying to open ComPort")
			EndIf
		Else
			closePort()
		EndIf
	Case ($msg = $CTRL_checkboxV) Or ($msg = $CTRL_checkboxI) Or ($msg = $CTRL_checkboxP) Or ($msg = $CTRL_checkboxW)
		If $curDevVersion = 2 Then 
			processParamCheckboxes($msg)
		EndIf	
	Case $msg = $CTRL_checkboxVl
		$doLogVoltage = _IsChecked($CTRL_checkboxVl) ? True : False
	Case $msg = $CTRL_checkboxVg
		$doPlotVoltage = _IsChecked($CTRL_checkboxVg) ? True : False
		processGraphCheckboxes($CTRL_checkboxVg)
	Case $msg = $CTRL_checkboxIl
		$doLogCurrent = _IsChecked($CTRL_checkboxIl) ? True : False
	Case $msg = $CTRL_checkboxIg
		$doPlotCurrent = _IsChecked($CTRL_checkboxIg) ? True : False
		processGraphCheckboxes($CTRL_checkboxIg)
	Case $msg = $CTRL_checkboxPl
		$doLogPower = _IsChecked($CTRL_checkboxPl) ? True : False
	Case $msg = $CTRL_checkboxPg
		$doPlotPower = _IsChecked($CTRL_checkboxPg) ? True : False
		processGraphCheckboxes($CTRL_checkboxPg)
	Case $msg = $CTRL_checkboxWl
		$doLogEnergy = _IsChecked($CTRL_checkboxWl) ? True : False
	Case $msg = $CTRL_checkboxWg
		$doPlotEnergy = _IsChecked($CTRL_checkboxWg) ? True : False
		processGraphCheckboxes($CTRL_checkboxWg)
	Case $msg = $CTRL_checkboxPFl
		$doLogPowerFactor = _IsChecked($CTRL_checkboxPFl) ? True : False
	Case $msg = $CTRL_checkboxPFg
		$doPlotPowerFactor = _IsChecked($CTRL_checkboxPFg) ? True : False
		processGraphCheckboxes($CTRL_checkboxPFg)
	Case $msg = $CTRL_checkboxFl
		$doLogFrequency = _IsChecked($CTRL_checkboxFl) ? True : False
	Case $msg = $CTRL_checkboxFg
		$doPlotFrequency = _IsChecked($CTRL_checkboxFg) ? True : False
		processGraphCheckboxes($CTRL_checkboxFg)
	Case $msg = $CTRL_btnResetEnergy
		$doResetEnergy	= True
	EndSelect

	
   
	If $portIsOpen = 1 Then
	
		If TimerDiff($pzemReqTimer) >= $pzemPollingDelay Then
			$pzemReqTimer = TimerInit()
			askPZEM()
		EndIf
		
		readPZEMPort()
	EndIf
	
	processPZEMReply()

Until $msg = $GUI_EVENT_CLOSE



; modifying request queue for V2.0 device
; this queue exists only for 2.0 version because there each value is requested separately
; also we're making interface adjustments
Func processParamCheckboxes($msg)
	Local $pos = 0
	
	For $i = 0 To  UBound($pzemReqList) -1
		$pzemReqList[$i] = 0
	Next

	If _IsChecked($CTRL_checkboxV) Then
		$pzemReqList[$pos] = $PZEM_REQ_V
		$pos += 1
	EndIf

	If _IsChecked($CTRL_checkboxI) Then
		$pzemReqList[$pos] = $PZEM_REQ_I
		$pos+=1
	EndIf

	If _IsChecked($CTRL_checkboxP) Then
		$pzemReqList[$pos] = $PZEM_REQ_P
		$pos+=1
	EndIf

	If _IsChecked($CTRL_checkboxW) Then
		$pzemReqList[$pos] = $PZEM_REQ_W
		$pos+=1
	EndIf

	$pzemCurReqPointer = 0
	$pzemNextReq = $pzemReqList[$pzemCurReqPointer]

	Select
		
		Case $msg = $CTRL_checkboxV
			If _IsChecked($CTRL_checkboxV) Then
				GUICtrlSetState ($CTRL_labelV, $GUI_ENABLE)
				GUICtrlSetState ($CTRL_checkboxVl, $GUI_ENABLE)
				GUICtrlSetState ($CTRL_checkboxVg, $GUI_ENABLE)
			Else
				GUICtrlSetData ( $CTRL_labelV, "-----")
				GUICtrlSetState ($CTRL_checkboxVl, $GUI_DISABLE)
				GUICtrlSetState ($CTRL_checkboxVg, $GUI_DISABLE)
				GUICtrlSetState ($CTRL_labelV,$GUI_DISABLE)
			EndIf
		Case $msg = $CTRL_checkboxI
			If _IsChecked($CTRL_checkboxI) Then
				GUICtrlSetState ($CTRL_labelI, $GUI_Enable)
				GUICtrlSetState ($CTRL_checkboxIl, $GUI_ENABLE)
				GUICtrlSetState ($CTRL_checkboxIg, $GUI_ENABLE)
			Else
				GUICtrlSetData ( $CTRL_labelI, "------")
				GUICtrlSetState ($CTRL_checkboxIl, $GUI_DISABLE)
				GUICtrlSetState ($CTRL_checkboxIg, $GUI_DISABLE)
				GUICtrlSetState ($CTRL_labelI,$GUI_DISABLE)
			EndIf
		Case $msg = $CTRL_checkboxP
			If _IsChecked($CTRL_checkboxP) Then
				GUICtrlSetState ($CTRL_labelP, $GUI_Enable)
				GUICtrlSetState ($CTRL_checkboxPl, $GUI_ENABLE)
				GUICtrlSetState ($CTRL_checkboxPg, $GUI_ENABLE)
			Else
				GUICtrlSetData ( $CTRL_labelP, "-----")
				GUICtrlSetState ($CTRL_checkboxPl, $GUI_DISABLE)
				GUICtrlSetState ($CTRL_checkboxPg, $GUI_DISABLE)
				GUICtrlSetState ($CTRL_labelP,$GUI_DISABLE)
			EndIf
		Case $msg = $CTRL_checkboxW
			If _IsChecked($CTRL_checkboxW) Then
				GUICtrlSetState ($CTRL_labelW, $GUI_Enable)
				GUICtrlSetState ($CTRL_checkboxWl, $GUI_ENABLE)
				GUICtrlSetState ($CTRL_checkboxWg, $GUI_ENABLE)
			Else
				GUICtrlSetData ( $CTRL_labelW, "------")
				GUICtrlSetState ($CTRL_labelW,$GUI_DISABLE)
				GUICtrlSetState ($CTRL_checkboxWl, $GUI_DISABLE)
				GUICtrlSetState ($CTRL_checkboxWg, $GUI_DISABLE)
			EndIf
	EndSelect
EndFunc



; Ensures that only one graph-checkbox would be checked
Func processGraphCheckboxes($chkbx)

	If $chkbx <> $CTRL_checkboxVg Then
		GUICtrlSetState($CTRL_checkboxVg, $GUI_UNCHECKED)
		$doPlotVoltage = False
	EndIf

	If $chkbx <> $CTRL_checkboxIg Then
		GUICtrlSetState($CTRL_checkboxIg, $GUI_UNCHECKED)
		$doPlotCurrent = False
	EndIf

	If $chkbx <> $CTRL_checkboxPg Then
		GUICtrlSetState($CTRL_checkboxPg, $GUI_UNCHECKED)
		$doPlotPower = False
	EndIf

	If $chkbx <> $CTRL_checkboxWg Then
		GUICtrlSetState($CTRL_checkboxWg, $GUI_UNCHECKED)
		$doPlotEnergy = False
	EndIf

	If $chkbx <> $CTRL_checkboxPFg Then
		GUICtrlSetState($CTRL_checkboxPFg, $GUI_UNCHECKED)
		$doPlotPowerFactor = False
	EndIf
	
	If $chkbx <> $CTRL_checkboxFg Then
		GUICtrlSetState($CTRL_checkboxFg, $GUI_UNCHECKED)
		$doPlotFrequency = False
	EndIf
	

	emptyGraphArea()

EndFunc


Func processPZEMreply()
	Local $checksum = 0

	If $curDevVersion = 2 And $pzemPortDataPointer >= 7 Then
		
		If 	$pzemPortDataReceived[0] = 0xA4 And $pzemPortDataReceived[1] = 0 And $pzemPortDataReceived[2] = 0 And _
			$pzemPortDataReceived[3] = 0 And $pzemPortDataReceived[4] = 0 And $pzemPortDataReceived[5] = 0  And _
			$pzemPortDataReceived[6] = 0xA4 Then
			$pzemInitialized = 1
			logString("PZEM was initialized successfully");
			trashPZEMData(7)
		EndIf
		
		If 	($pzemPortDataReceived[0] = 0xA0 Or $pzemPortDataReceived[0] = 0xA1 Or _
			$pzemPortDataReceived[0] = 0xA2 Or $pzemPortDataReceived[0] = 0xA3) Then
			For $i = 0 To 5
				$checksum += $pzemPortDataReceived[$i]
			Next
			$checksum = Mod($checksum, 256)
			If $checksum <> $pzemPortDataReceived[6] Then
				logString("Wrong checksum in incoming data" & $checksum & " " & $pzemPortDataReceived[6])
				trashPZEMData(1)
				Return
			Else
				showValueDigitsV2($pzemPortDataReceived)
				trashPZEMData(7)
			EndIf
		Else ; there is no header in the byte 0
			trashPZEMData(1)
		EndIf	
	
	ElseIf $curDevVersion = 3 Then
		; if we have something that resembles the right header...
		If 	$pzemPortDataPointer >= 2 And $pzemPortDataReceived[0] = 0xF8 And _
			( $pzemPortDataReceived[1] = $pzem_measOKcode Or _
			$pzemPortDataReceived[1] = $pzem_measERRcode Or _
			$pzemPortDataReceived[1] = $pzem_nrjResOKcode Or _
			$pzemPortDataReceived[1] = $pzem_nrjResERRcode) Then
			
				If $pzemPortDataPointer >= $pzem_measOKlen And $pzemPortDataReceived[1] = $pzem_measOKcode Then
					$checksum = Number("0x" & Hex($pzemPortDataReceived[$pzem_measOKlen-1],2) & Hex($pzemPortDataReceived[$pzem_measOKlen-2],2))
					
					If $checksum = MODBUScrc16($pzemPortDataReceived, $pzem_measOKlen-2) Then
						showValueDigitsV3($pzemPortDataReceived)
						trashPZEMData($pzem_measOKlen)
					Else
						logString("Wrong checksum in incoming data")
						trashPZEMData(1)
					EndIf
				EndIf
				
				If $pzemPortDataPointer >= $pzem_measERRlen And $pzemPortDataReceived[1] = $pzem_measERRcode Then
					$checksum = Number("0x" & Hex($pzemPortDataReceived[$pzem_measERRlen-1],2) & Hex($pzemPortDataReceived[$pzem_measERRlen-2],2))
					If $checksum = MODBUScrc16($pzemPortDataReceived, $pzem_measERRlen-2) Then
						logString("Мeasurement ERROR")
						trashPZEMData($pzem_measERRlen)
					Else
						logString("Wrong checksum in incoming data")
						trashPZEMData(1)
					EndIf
					
					
					
				EndIf
				
				If $pzemPortDataPointer >= $pzem_nrjResOKlen And $pzemPortDataReceived[1] = $pzem_nrjResOKcode Then
					$checksum = Number("0x" & Hex($pzemPortDataReceived[$pzem_nrjResOKlen-1],2) & Hex($pzemPortDataReceived[$pzem_nrjResOKlen-2],2))
					If $checksum = MODBUScrc16($pzemPortDataReceived, $pzem_nrjResOKlen-2) Then
						logString("Energy RESET OK")
						trashPZEMData($pzem_nrjResOKlen)
					Else
						logString("Wrong checksum in incoming data")
						trashPZEMData(1)
					EndIf
				EndIf
				
				If $pzemPortDataPointer >= $pzem_nrjResERRlen And $pzemPortDataReceived[1] = $pzem_nrjResERRcode Then
					$checksum = Number("0x" & Hex($pzemPortDataReceived[$pzem_nrjResERRlen-1],2) & Hex($pzemPortDataReceived[$pzem_nrjResERRlen-2],2))
					If $checksum = MODBUScrc16($pzemPortDataReceived, $pzem_nrjResERRlen-2) Then
						logString("Energy RESET ERROR")
						trashPZEMData($pzem_nrjResERRlen)
					Else
						logString("Wrong checksum in incoming data")
						trashPZEMData(1)
					EndIf
				EndIf

		Else ;we have enough data in buffer to recognize the right header but there is none
			trashPZEMData(1)
		EndIf
	
		 
	EndIf

EndFunc


Func trashPZEMData($numBytes)
	For $i = 0 To $numBytes-1
		_ArrayPush ( $pzemPortDataReceived, 0)
	Next
	If $pzemPortDataPointer >= $numBytes Then
		$pzemPortDataPointer-= $numBytes
	Else
		$pzemPortDataPointer = 0
	EndIf
EndFunc


Func readPZEMPort()
	Local $pzemData = _CommAPI_ReceiveBinary($hPort, $portReadTimeout, 16, "");
	If (@error and @error <> -2) Then
		logString("Error reading ComPort: " & @error) ; -2 is timeout error
	Else
		If BinaryLen($pzemData) > 0 Then
			For $j = 0 To  BinaryLen($pzemData) -1
				$pzemPortDataReceived[$pzemPortDataPointer] = Number( BinaryMid($pzemData, $j+1, 1))
				$pzemPortDataPointer+=1
			Next
			Return
		Else
			Return
		EndIf
	EndIf  
EndFunc





Func PZEM_init()
	If $curDevVersion = 2 Then
		$pzemInitialized = 0
		_CommAPI_TransmitBinary($hPort, $pzem_setaddr)
	EndIf
EndFunc


Func closePort()
	_CommAPI_ClosePort($hPort)
	If @error Then
		logString("Error while closing ComPort " & $openedPortNum & ": " & @error)
	Else
		logString("ComPort " & $openedPortNum & " is closed successfully")
		$portIsOpen = 0
		GUICtrlSetData 	($CTRL_labelV, "-----")	
		GUICtrlSetData 	($CTRL_labelI, "------")
		GUICtrlSetData 	($CTRL_labelP, "-----")
		GUICtrlSetData 	($CTRL_labelW, "------")
		GUICtrlSetData 	($CTRL_labelPF, "-----")
		GUICtrlSetData 	($CTRL_labelF, "------")

		GUICtrlSetState ($CTRL_PortsComboList,$GUI_ENABLE)
		GUICtrlSetState ($CTRL_btnRefreshPortList,$GUI_ENABLE)
		GUICtrlSetData ( $CTRL_btnOpenPort, "Connect")
		$openedPortNum = "";		
   EndIf
   $pzemInitialized = 0
EndFunc
;============================================================================================
Func openPort()

	Local $myErr = ""
	Local $selectedPort = GUICtrlRead($CTRL_PortsComboList)
	logString("Attempting to open port")
	$pzemInitialized = 0

	If Not StringRegExp($selectedPort, '\d+') Then
		logString("unable to detect port number in port name")
		Return 0
	EndIf

	$selectedPort = Number(  StringRegExpReplace($selectedPort, '\D', '') )

	If $selectedPort < 1 Or $selectedPort = "" Then
		logString("unable to detect port number")
		Return 0
	Else
		logString("port number is " & $selectedPort)
	EndIf

   ;$r = _CommSetPort($selectedPort,$myErr,9600,8,0,1,0,0,0)
	$hPort = _CommAPI_OpenCOMPort($selectedPort, 9600, 0, 8, "1")

	If @error Then
		logString("failed to open ComPort " & $selectedPort & " with error " & _WinAPI_GetLastError())
		Return 0
	Else
		logString("ComPort " & $selectedPort & " is opened successfully")
		$portIsOpen = 1
		$openedPortNum = $selectedPort
		GUICtrlSetState ($CTRL_PortsComboList,$GUI_DISABLE)
		GUICtrlSetState ($CTRL_btnRefreshPortList,$GUI_DISABLE)
		GUICtrlSetData ( $CTRL_btnOpenPort, "Disconnect")
		Return 1
	EndIf
EndFunc
;================================================================================================
Func updateCommPortsComboList()

   $sList = ""
   $commPortsList = _my_GetCOMPorts()

;assuming com ports have names like COM5
   For $i = 0 To  UBound($commPortsList) -1
	   $commPortsList[$i] = Number( StringRegExp ( $commPortsList[$i], '\(COM(\d+)\)' , $STR_REGEXPARRAYMATCH, 1 )[0] )
	   ;logString($commPortsList[$i])
   Next

   _ArraySort($commPortsList)

   For $i = 0 To  UBound($commPortsList) -1
	  $sList &= "|" & "COM" & $commPortsList[$i]
   Next

   GUICtrlSetData($CTRL_PortsComboList,  $sList)

EndFunc
;==================================================================================================
Func logString($myString)
	_ArrayPush ( $logArray, getTimestamp() & $myString, 1   )
	Local $r = GUICtrlSetData($CTRL_editLOG,  _ArrayToString($logArray, @CRLF))
	Return
EndFunc
;==================================================================================================
Func getTimestamp()
   Return @YEAR & "-" & @MON & "-" & @MDAY & " " & @HOUR & ":" & @MIN & ":" & @SEC & "  -  "
EndFunc



Func askPZEM()

	If $curDevVersion = 2 Then
   
		If $pzemInitialized = 0 Then Return

		If $pzemNextReq = $PZEM_REQ_V Then
			_CommAPI_TransmitBinary($hPort, $pzem_readV)
		ElseIf $pzemNextReq = $PZEM_REQ_I Then
			_CommAPI_TransmitBinary($hPort, $pzem_readI)
		ElseIf $pzemNextReq = $PZEM_REQ_P Then
			_CommAPI_TransmitBinary($hPort, $pzem_readP)
		ElseIf $pzemNextReq = $PZEM_REQ_W Then
			_CommAPI_TransmitBinary($hPort, $pzem_readW)
		EndIf

		$pzemCurReqPointer +=1;
		If ($pzemCurReqPointer > 4) Or ($pzemReqList[$pzemCurReqPointer] = 0) Then $pzemCurReqPointer = 0
		$pzemNextReq = $pzemReqList[$pzemCurReqPointer]
	
	ElseIf $curDevVersion = 3 Then
		if $doResetEnergy Then
			_CommAPI_TransmitBinary($hPort, $pzem_resetEnergyReq)
			$doResetEnergy = False
		Else
			_CommAPI_TransmitBinary($hPort, $pzem_getMeasReq)
		EndIf
	EndIf

EndFunc



Func _IsChecked($idControlID)
    Return BitAND(GUICtrlRead($idControlID), $GUI_CHECKED) = $GUI_CHECKED
EndFunc




Func _my_GetCOMPorts()

   Local $outArray[0]

	Local $oWMIService = ObjGet("winmgmts:\\localhost\root\CIMV2")
	If @error Then Return SetError(@error, @ScriptLineNumber, "")
	Local $oItems = $oWMIService.ExecQuery("SELECT * FROM Win32_PnPEntity WHERE Name LIKE '%(COM[0-9]%)'", "WQL", 48)

   Local $n = 0
	For $oItem In $oItems
	  ReDim $outArray[$n+1]
	  $outArray[$n] = $oItem.Name
	  $n = $n+1
	Next
	Return $outArray
EndFunc



Func showValueDigitsV3(Const $pzb)
	Local $arr
	Local $precision = -1
	
	Local $voltage = Number("0x" & Hex($pzb[3],2) & Hex($pzb[4],2) ) / 10
	GUICtrlSetData ( $CTRL_labelV, StringFormat("%#.1f", $voltage))
	If $doLogVoltage Then logString("V=" & $voltage &" V  [" & $voltageTick & "]")
	pushGraphData($voltageArr, $voltageTick, $voltage)
	$voltageTick += 1
	If $doPlotVoltage 	Then
		$arr = $voltageArr
		$precision = 1	
	EndIf
	
	
	Local $current = Number("0x" & Hex($pzb[7],2) & Hex($pzb[8],2) & Hex($pzb[5],2) & Hex($pzb[6],2)) /1000
	If $current < 100 Then 
		GUICtrlSetData ( $CTRL_labelI, StringFormat("%#.3f", $current))
	Else
		GUICtrlSetData ( $CTRL_labelI, StringFormat("%#.2f", $current))
	EndIf
	If $doLogCurrent Then logString("I=" & $current &" A  [" & $currentTick & "]")
	pushGraphData($currentArr, $currentTick, Number(StringFormat("%#.3f", $current)))
	$currentTick += 1
	If $doPlotCurrent 	Then
		$arr = $currentArr
		$precision = 3
	EndIf
	
	
	Local $power = Number("0x" & Hex($pzb[11],2) & Hex($pzb[12],2) & Hex($pzb[9],2) & Hex($pzb[10],2) ) /10
	If $power <= 999 Then
		GUICtrlSetData ( $CTRL_labelP, StringFormat("%#.1f", $power))
	Else
		GUICtrlSetData ( $CTRL_labelP, StringFormat("%u", $power))
	EndIf
	If $doLogPower Then logString("P=" & $power &" W  [" & $powerTick & "]")
	pushGraphData($powerArr, $powerTick, Number(StringFormat("%#.1f", $power)))
	$powerTick += 1
	If $doPlotPower 	Then
		$arr = $powerArr
		$precision = 1
	EndIf
	
	
	Local $energy = Number("0x" & Hex($pzb[15],2) & Hex($pzb[16],2) & Hex($pzb[13],2) & Hex($pzb[14],2) )
	GUICtrlSetData ( $CTRL_labelW, StringFormat("%u", $energy))
	If $doLogEnergy Then logString("E=" & $energy &" Wh  [" & $energyTick & "]")
	pushGraphData($energyArr, $energyTick, Number(StringFormat("%u", $energy)))
	$energyTick += 1
	If $doPlotEnergy 	Then
		$arr = $energyArr
		$precision = 0
	EndIf
	
	
	Local $powerfactor = Number("0x" & Hex($pzb[19],2) & Hex($pzb[20],2) ) / 100
	GUICtrlSetData ( $CTRL_labelPF, StringFormat("%#.2f", $powerfactor))
	If $doLogPowerFactor Then logString("φ=" & $powerfactor &"  [" & $powerfactorTick & "]")
	pushGraphData($powerfactorArr, $powerfactorTick, Number(StringFormat("%#.2f",$powerfactor)))
	$powerfactorTick += 1
	If $doPlotPowerFactor 	Then
		$arr = $powerfactorArr
		$precision = 2
	EndIf
	
	
	Local $frequency = Number("0x" & Hex($pzb[17],2) & Hex($pzb[18],2)) /10
	GUICtrlSetData ( $CTRL_labelF, StringFormat("%#.1f", $frequency))
	If $doLogFrequency Then logString("f=" & $frequency &" Hz  [" & $frequencyTick & "]")
	pushGraphData($frequencyArr, $frequencyTick, Number(StringFormat("%#.1f", $frequency)))
	$frequencyTick += 1
	If $doPlotFrequency 	Then
		$arr = $frequencyArr
		$precision = 1
	EndIf
	
	
	If $precision >= 0 Then processGraphData($arr, $precision)
EndFunc

Func showValueDigitsV2(Const $pzb)

	Local $arr
	Local $precision
	

	If $pzb[0] = 0xA0 Then  ;It's a voltage
		Local $vi = Number(Binary("0x" & Hex($pzb[2],2) & Hex($pzb[1],2)))
		Local $vf = $pzb[3]
	
		If _ArraySearch ( $pzemReqList, 1) >= 0  Then  ;if voltage is still checked on GUI
			GUICtrlSetData ( $CTRL_labelV, $vi & "." & $vf)
			
			If $doLogVoltage Then logString($vi & "." & $vf &" V  [" & $voltageTick & "]")
			pushGraphData($voltageArr, $voltageTick, Number($vi & "." & $vf))
			$voltageTick += 1
			
			If $doPlotVoltage 	Then
				$arr = $voltageArr
				$precision = 1	  
				If _IsChecked($CTRL_checkboxV) = False Then Return ; do not update graph if datasource is disabled
				processGraphData($arr, $precision)
			EndIf
		Else
			GUICtrlSetData ( $CTRL_labelV, "-----")
		EndIf
	
		Return
	EndIf
	
	
	If $pzb[0] = 0xA1 Then  ;It's a current
		Local $ci = $pzb[2];
		Local $cf = $pzb[3];
	
		If _ArraySearch ( $pzemReqList, 2) >= 0 Then  ;if current is still checked on GUI
			GUICtrlSetData ( $CTRL_labelI, StringFormat("%u.%02u", $ci, $cf))
			
			If $doLogCurrent Then logString(StringFormat("%u.%02u A [%u]", $ci, $cf, $currentTick))
			pushGraphData($currentArr, $currentTick, Number(StringFormat("%u.%02u", $ci, $cf)))
			$currentTick += 1
			
			If $doPlotCurrent Then
				$arr = $currentArr
				$precision = 2
				If _IsChecked($CTRL_checkboxI) = False Then Return
				processGraphData($arr, $precision)
			EndIf
		Else
			GUICtrlSetData ( $CTRL_labelI, "------")
		EndIf
	
		Return
	EndIf
	
	If $pzb[0] = 0xA2 Then  ;It's a power
		Local $pi = Number(Binary("0x" & Hex($pzb[2],2) & Hex($pzb[1],2)))
	
		If _ArraySearch ( $pzemReqList, 3) >= 0  Then  ;if power is still checked on GUI
			GUICtrlSetData ( $CTRL_labelP, $pi)
			
			If $doLogPower Then logString($pi & " W [" & $powerTick & "]")
			pushGraphData($powerArr, $powerTick, Number($pi))
			$powerTick += 1
			
			If $doPlotPower	Then
				$arr = $powerArr
				$precision = 0
				If _IsChecked($CTRL_checkboxP) = False Then Return
				processGraphData($arr, $precision)
			EndIf
		Else
			GUICtrlSetData ( $CTRL_labelP, "-----")
		EndIf
	
		Return
	EndIf
	
	
	If $pzb[0] = 0xA3 Then  ;It's an energy
		Local $wi = Number(Binary("0x" & Hex($pzb[3],2) & Hex($pzb[2],2) & Hex($pzb[1],2)))
	
		If _ArraySearch ( $pzemReqList, 4) >= 0  Then  ;if energy is still checked on GUI
			GUICtrlSetData ( $CTRL_labelW, $wi)
			
			If $doLogEnergy Then logString($wi & " Wh [" & $energyTick & "]")
			pushGraphData($energyArr, $energyTick, Number( StringRegExp( $wi, "\d{1,4}$",1)[0]) )
			$energyTick += 1
			
			If $doPlotEnergy	Then
				$arr = $energyArr
				$precision = 0
				If _IsChecked($CTRL_checkboxW) = False Then Return
				processGraphData($arr, $precision)
			EndIf
		Else
			GUICtrlSetData ( $CTRL_labelW, "------")
		EndIf
	
		Return
	EndIf
	

EndFunc



Func processGraphData($arr, $precision)

   Local $graphMax = getGraphArrMax($arr)
   Local $graphMin = getGraphArrMin($arr)
   Local $graphDiff = $graphMax - $graphMin
   Local $myMax, $myMin

   ; precision 0 -> Y span should be at least 10
   ; precision 1 -> Y span should be at least 1
   ; precision 2 -> Y span should be at least 0.1

   Local $precisionToSpan[4] = [10, 1, 0.1, 0.01]

   If $graphDiff <> 0 Then
	  $myMax = $graphMax + Round(($graphDiff * 0.5), $precision)
	  $myMin = $graphMin - Round(($graphDiff * 0.5), $precision)

	  If ($myMax - $myMin) < $precisionToSpan[$precision] Then
		 Local $diff = $precisionToSpan[$precision] - ($myMax - $myMin)
		 $myMax = $myMax + Round($diff/2, $precision)
		 $myMin = $myMin - Round($diff/2, $precision)
	  EndIf



   Else
	  $myMax = $graphMax + $precisionToSpan[$precision]/2
	  $myMin = $graphMin - $precisionToSpan[$precision]/2
   EndIf

   If $myMin < 0 Then
	  $myMax -= $myMin
	  $myMin = 0
   EndIf

   Local $yTicksCount = 10
   Local $yTicksStep = 1

   Local $yTickWidth = Round(($myMax - $myMin)/$yTicksCount, $precision)
   $myMax = $myMin + $yTickWidth*$yTicksCount


	_GraphGDIPlus_Clear($Graph)
	
	; to avoid unnecessary flickering we repaint X labels only when they begin to slide
	If $arr[$graphXResolution-1][0] <> -1 Then  ; the last cell in array is filled
		_GraphGDIPlus_Update_LabelsX($Graph,$arr[0][0],$arr[0][0]+$graphXResolution,20,1,0)
	EndIf
	; to avoid unnecessary flickering we repaint Y labels only if they were changed
	If $graphYmin <> $myMin Or $graphYmax <> $myMax Or $graphPrecision <> $precision Then
		_GraphGDIPlus_Update_LabelsY($Graph,$myMin,$myMax,10,1,$precision)
		$graphYmin = $myMin
		$graphYmax = $myMax
		$graphPrecision = $precision
	EndIf

  _GraphGDIPlus_Set_GridX($Graph,1,0xFF6993BE)
   _GraphGDIPlus_Set_GridY($Graph,$yTickWidth,0xFF6993BE)

   For $i = 0 to UBound( $arr, 1) - 1
	  If $arr[$i][0] = -1 Then ExitLoop ; not filled yet

	  If $i = 0 Then
		 _GraphGDIPlus_Plot_Start($Graph,$arr[$i][0],$arr[$i][1])
	  Else
		 _GraphGDIPlus_Plot_Line($Graph,$arr[$i][0],$arr[$i][1])
	  EndIf

   Next
   _GraphGDIPlus_Refresh($Graph)


EndFunc

Func getGraphArrMin(Const ByRef $arr)
   Local $min = 1000000

   For $i = 0 to UBound( $arr, 1) - 1
	  If $arr[$i][0] <> -1 And $arr[$i][1] < $min Then $min = $arr[$i][1]
   Next

   Return $min
EndFunc

Func getGraphArrMax(Const ByRef $arr)
   Local $max = 0

   For $i = 0 to UBound( $arr, 1) - 1
	  If $arr[$i][0] <> -1 And $arr[$i][1] > $max Then $max = $arr[$i][1]
   Next

   Return $max
EndFunc

Func pushGraphData(ByRef $arr, Const $tick, Const $value)

	  If $tick <  UBound( $arr, 1) Then
		 $arr[$tick][0] = $tick
		 $arr[$tick][1] = $value
	  Else
		 Local $tmparr[2] = [$tick, $value]

		 For $i = 0 to UBound( $arr, 1) - 2
			$arr[$i][0] = $arr[$i+1][0]
			$arr[$i][1] = $arr[$i+1][1]
		 Next

		 $arr[UBound( $arr, 1) - 1][0] = $tick
		 $arr[UBound( $arr, 1) - 1][1] = $value
	  EndIf

EndFunc

Func MODBUScrc16(ByRef $buffer, Const $sz)
	Local $crc = 0xFFFF
    Local $odd
	
	For $i = 0 To $sz-1 Step 1 
        $crc = BitXOR ($crc, $buffer[$i])
		For $j = 0 To 7 Step 1
			$odd = BitAND($crc, 0x0001)
			$crc = BitShift($crc, 1)
			If ($odd <> 0) Then $crc = BitXOR($crc, 0xA001)  
		Next
	Next
	
	Return $crc
	  
EndFunc


Func checkInputField(Const $data, Const $min, Const $max)
   If StringRegExp ( $data, '\D' )  Then
	  MsgBox(4096,"Error","Input must contain only digits: " & $data)
	  Return False
   EndIf

   Local $n = Number($data)

   If $n < $min Then
	  MsgBox(4096,"Error","Number is too small: " & $data)
	  Return False
   EndIf

   If $n > $max Then
	  MsgBox(4096,"Error","Number is too large: " & $data)
	  Return False
   EndIf

   Return True
EndFunc

Func initGraphArray(ByRef $arr)
   For $i = 0 to UBound( $arr, 1) - 1
	  For $j = 0 to UBound($arr, 2) - 1
        $arr[$i][$j] = -1
	  Next
   Next
EndFunc

Func emptyGraphArea()
	_GraphGDIPlus_Clear($Graph)
	processGraphData($emptyArr, 0)
	_GraphGDIPlus_Clear($Graph)
	_GraphGDIPlus_Set_RangeX($Graph,0,$graphXResolution,20,1,0)
	_GraphGDIPlus_Set_RangeY($Graph,0,100,10,1,0)
	
EndFunc

Func initGraphArea()
   _GraphGDIPlus_Clear($Graph)
   _GraphGDIPlus_Set_RangeX($Graph,0,$graphXResolution,20,1,0)
   _GraphGDIPlus_Set_RangeY($Graph,0,100,10,1,0)

   _GraphGDIPlus_Set_PenColor($Graph,0xFF325D87)
   _GraphGDIPlus_Set_PenSize($Graph,2)
EndFunc

Func resetGUI(Const $devVersion)

	GUICtrlSetData 	($CTRL_labelV, "-----")	
	GUICtrlSetData 	($CTRL_labelI, "------")
	GUICtrlSetData 	($CTRL_labelP, "-----")
	GUICtrlSetData 	($CTRL_labelW, "------")
	GUICtrlSetData 	($CTRL_labelPF, "-----")
	GUICtrlSetData 	($CTRL_labelF, "------")
	
	
	GUICtrlSetState	($CTRL_checkboxVg, $GUI_UNCHECKED)
	GUICtrlSetState	($CTRL_checkboxVl, $GUI_UNCHECKED)
	GUICtrlSetState	($CTRL_checkboxIg, $GUI_UNCHECKED)
	GUICtrlSetState	($CTRL_checkboxIl, $GUI_UNCHECKED)
	GUICtrlSetState	($CTRL_checkboxPg, $GUI_UNCHECKED)
	GUICtrlSetState	($CTRL_checkboxPl, $GUI_UNCHECKED)
	GUICtrlSetState	($CTRL_checkboxWg, $GUI_UNCHECKED)
	GUICtrlSetState	($CTRL_checkboxWl, $GUI_UNCHECKED)
	GUICtrlSetState	($CTRL_checkboxPFg, $GUI_UNCHECKED)
	GUICtrlSetState	($CTRL_checkboxPFl, $GUI_UNCHECKED)
	GUICtrlSetState	($CTRL_checkboxFg, $GUI_UNCHECKED)
	GUICtrlSetState	($CTRL_checkboxFl, $GUI_UNCHECKED)
	
	If $devVersion = 2 Then
	
		GUICtrlSetState ($CTRL_labelV,$GUI_DISABLE)
		GUICtrlSetState ($CTRL_labelI,$GUI_DISABLE)
		GUICtrlSetState ($CTRL_labelP,$GUI_DISABLE)
		GUICtrlSetState ($CTRL_labelW,$GUI_DISABLE)
		GUICtrlSetState ($CTRL_labelPF,$GUI_DISABLE)
		GUICtrlSetState ($CTRL_labelF,$GUI_DISABLE)
		
		GUICtrlSetState ($CTRL_checkboxV,	$GUI_ENABLE)
		GUICtrlSetState ($CTRL_checkboxI,	$GUI_ENABLE)
		GUICtrlSetState ($CTRL_checkboxP,	$GUI_ENABLE)
		GUICtrlSetState ($CTRL_checkboxW,	$GUI_ENABLE)
		
		GUICtrlSetState	($CTRL_checkboxV, $GUI_UNCHECKED)
		GUICtrlSetState	($CTRL_checkboxI, $GUI_UNCHECKED)
		GUICtrlSetState	($CTRL_checkboxP, $GUI_UNCHECKED)
		GUICtrlSetState	($CTRL_checkboxW, $GUI_UNCHECKED)
		GUICtrlSetState	($CTRL_checkboxPF, $GUI_UNCHECKED)
		GUICtrlSetState	($CTRL_checkboxF, $GUI_UNCHECKED)
		
		GUICtrlSetState ($CTRL_checkboxPF, $GUI_DISABLE)
		GUICtrlSetState ($CTRL_checkboxF, $GUI_DISABLE)
		
		GUICtrlSetState ($CTRL_checkboxVl, $GUI_DISABLE)
		GUICtrlSetState ($CTRL_checkboxVg, $GUI_DISABLE)
		GUICtrlSetState ($CTRL_checkboxIl, $GUI_DISABLE)
		GUICtrlSetState ($CTRL_checkboxIg, $GUI_DISABLE)
		GUICtrlSetState ($CTRL_checkboxPl, $GUI_DISABLE)
		GUICtrlSetState ($CTRL_checkboxPg, $GUI_DISABLE)
		GUICtrlSetState ($CTRL_checkboxWl, $GUI_DISABLE)
		GUICtrlSetState ($CTRL_checkboxWg, $GUI_DISABLE)
		GUICtrlSetState ($CTRL_checkboxPFl, $GUI_DISABLE)
		GUICtrlSetState ($CTRL_checkboxPFg, $GUI_DISABLE)
		GUICtrlSetState ($CTRL_checkboxFl, $GUI_DISABLE)
		GUICtrlSetState ($CTRL_checkboxFg, $GUI_DISABLE)
		
		GUICtrlSetState ($CTRL_btnResetEnergy, $GUI_DISABLE)
		
	
	ElseIf $devVersion = 3 Then
		
		GUICtrlSetState ($CTRL_labelV,$GUI_ENABLE)
		GUICtrlSetState ($CTRL_labelI,$GUI_ENABLE)
		GUICtrlSetState ($CTRL_labelP,$GUI_ENABLE)
		GUICtrlSetState ($CTRL_labelW,$GUI_ENABLE)
		GUICtrlSetState ($CTRL_labelPF,$GUI_ENABLE)
		GUICtrlSetState ($CTRL_labelF,$GUI_ENABLE)
	
		GUICtrlSetState	($CTRL_checkboxV, $GUI_CHECKED)
		GUICtrlSetState	($CTRL_checkboxI, $GUI_CHECKED)
		GUICtrlSetState	($CTRL_checkboxP, $GUI_CHECKED)
		GUICtrlSetState	($CTRL_checkboxW, $GUI_CHECKED)
		GUICtrlSetState	($CTRL_checkboxPF, $GUI_CHECKED)
		GUICtrlSetState	($CTRL_checkboxF, $GUI_CHECKED)
		
		GUICtrlSetState ($CTRL_checkboxV,	$GUI_DISABLE)
		GUICtrlSetState ($CTRL_checkboxI,	$GUI_DISABLE)
		GUICtrlSetState ($CTRL_checkboxP,	$GUI_DISABLE)
		GUICtrlSetState ($CTRL_checkboxW,	$GUI_DISABLE)
		GUICtrlSetState ($CTRL_checkboxPF, 	$GUI_DISABLE)
		GUICtrlSetState ($CTRL_checkboxF, 	$GUI_DISABLE)
		GUICtrlSetState ($CTRL_checkboxWl, $GUI_DISABLE)
		GUICtrlSetState ($CTRL_checkboxWg, $GUI_DISABLE)
		GUICtrlSetState ($CTRL_checkboxPFl, $GUI_DISABLE)
		GUICtrlSetState ($CTRL_checkboxPFg, $GUI_DISABLE)
		
		GUICtrlSetState ($CTRL_checkboxVl, $GUI_ENABLE)
		GUICtrlSetState ($CTRL_checkboxVg, $GUI_ENABLE)
		GUICtrlSetState ($CTRL_checkboxIl, $GUI_ENABLE)
		GUICtrlSetState ($CTRL_checkboxIg, $GUI_ENABLE)
		GUICtrlSetState ($CTRL_checkboxPl, $GUI_ENABLE)
		GUICtrlSetState ($CTRL_checkboxPg, $GUI_ENABLE)
		GUICtrlSetState ($CTRL_checkboxWl, $GUI_ENABLE)
		GUICtrlSetState ($CTRL_checkboxWg, $GUI_ENABLE)
		GUICtrlSetState ($CTRL_checkboxPFl, $GUI_ENABLE)
		GUICtrlSetState ($CTRL_checkboxPFg, $GUI_ENABLE)
		GUICtrlSetState ($CTRL_checkboxFl, $GUI_ENABLE)
		GUICtrlSetState ($CTRL_checkboxFg, $GUI_ENABLE)
		
		GUICtrlSetState ($CTRL_btnResetEnergy, $GUI_ENABLE)
		
	Else
		logString("Device version is unknown" )
	EndIf
	
EndFunc